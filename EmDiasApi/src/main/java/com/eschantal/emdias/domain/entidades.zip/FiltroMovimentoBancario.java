package com.eschantal.emdias.domain;

import java.time.ZonedDateTime;

public class FiltroMovimentoBancario {

    private long accountBankId ;
    private ZonedDateTime dataInicial;
    private ZonedDateTime dataFinal;

    public long getAccountBankId() {
        return accountBankId;
    }

    public void setAccountBankId(long accountBankId) {
        this.accountBankId = accountBankId;
    }

    public ZonedDateTime getDataInicial() {
        return dataInicial;
    }

    public void setDataInicial(ZonedDateTime dataInicial) {
        this.dataInicial = dataInicial;
    }

    public ZonedDateTime getDataFinal() {
        return dataFinal;
    }

    public void setDataFinal(ZonedDateTime dataFinal) {
        this.dataFinal = dataFinal;
    }
}
