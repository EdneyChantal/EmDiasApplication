package com.eschantal.emdias.domain;


import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "tbnatureplan")
public class NaturePlan  implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_natureplan")
    private Long id;

    @ManyToOne
    @JoinColumns(@JoinColumn(name = "id_workspace" , referencedColumnName = "id_workspace"))
    private WorkSpace workSpace;

    @Column(name="ds_natureplan")
    String descNaturePlan;

    @ManyToOne
    @JoinColumns(@JoinColumn(name = "id_natureplan_father"))
    private NaturePlan naturePlanFather;


    @Enumerated(EnumType.STRING)
    @Column(name="ind_type")
    private TypeNaturePlan typeNaturePlan;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public WorkSpace getWorkSpace() {
        return workSpace;
    }

    public NaturePlan workSpace(WorkSpace workSpace) {
        this.workSpace = workSpace;
        return this;
    }

    public String getDescNaturePlan() {
        return descNaturePlan;
    }

    public NaturePlan descNaturePlan(String descNaturePlan) {
        this.descNaturePlan = descNaturePlan;
        return this;
    }

    public TypeNaturePlan getTypeNaturePlan() {
        return typeNaturePlan;
    }

    public NaturePlan typeNaturePlan(TypeNaturePlan typeNaturePlan) {
        this.typeNaturePlan = typeNaturePlan;
        return this;
    }

    public NaturePlan getNaturePlanFather() {
        return naturePlanFather;
    }

    public NaturePlan naturePlanFather(NaturePlan naturePlanFather) {
        this.naturePlanFather = naturePlanFather;
        return this;
    }
}
