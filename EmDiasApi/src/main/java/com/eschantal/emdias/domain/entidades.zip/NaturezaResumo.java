package com.eschantal.emdias.domain;

import javax.persistence.*;
import java.io.Serializable;


public class NaturezaResumo implements Serializable {


    private static final long serialVersionUID = 1L;


    private long idNature;

    private double valorTotal;

    private NaturePlan naturePlan;


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public long getIdNature() {
        return idNature;
    }

    public void setIdNature(long idNature) {
        this.idNature = idNature;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public NaturePlan getNaturePlan() {
        return naturePlan;
    }

    public void setNaturePlan(NaturePlan naturePlan) {
        this.naturePlan = naturePlan;
    }
}
