package com.eschantal.emdias.domain;

public enum TypeNaturePlan {
    R,
    D,
}
