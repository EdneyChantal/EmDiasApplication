package com.eschantal.emdias.domain.enumeration;

/**
 * The TypeNaturePlan enumeration.
 */
public enum TypeNaturePlan {
    R, D
}
