/**
 * JPA domain objects.
 */
package com.eschantal.emdias.domain;
